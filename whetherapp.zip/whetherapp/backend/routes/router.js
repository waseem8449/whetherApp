const express = require("express");
const router = express.Router();
const users = require("../Db/models/userSchema");
const cities = require("../Db/models/cityschema");
const jwt = require("jsonwebtoken");
const { requireSignin } = require("../common-middleware");

router.post("/register", async (req, res) => {
  const { name, email, password, mobile } = req.body;

  if (!name || !email || !password || !mobile) {
    res.status(404).json("plwease fill data");
  }
  try {
    const preuser = await users.findOne({ email: email });
    if (preuser) {
      res.status(404).json("this uer is already present");
    } else {
      const adduser = new users({
        name,
        email,
        password,
        mobile,
      });
      await adduser.save();
      res.status(201).json(adduser);
      console.log(adduser);
    }
  } catch (error) {
    res.status(404).json(error);
  }
});
//delete

router.delete("/deleteuser/:_id", requireSignin, async (req, res) => {
  try {
    let data = await users.deleteOne(req.params);
    console.log(data);
    res.status(201).json(data);
  } catch (error) {
    res.status(404).json(error);
  }
});
//listing

router.get("/getdata", requireSignin, async (req, res) => {
  try {
    let data = await users.find();
    res.status(201).json(data);
    console.log(data);
  } catch (error) {
    res.status(404).json(error);
  }
});
router.post("/Login", (req, res) => {
  const { email, password } = req.body;
  try {
    users.findOne({ email: email }, (err, user) => {
      if (user) {
        if (user.authenticate(req.body.password)) {
          const token = jwt.sign({ _id: user._id }, "waseem", {
            expiresIn: "1d",
          });
          res.status(200).json({
            token,
          });
        }
      } else {
        return res.status(400).json({ message: "Something went wrong" });
      }
    });
  } catch (error) {
    return error;
  }
});
router.post("/addCity", requireSignin, async (req, res) => {
  // console.log("eq.body");
  const { city } = req.body;

  if (!city) {
    res.status(404).json("plwease fill city");
  }
  try {
    const preuser = await cities.findOne({ city });
    // console.log(preuser);
    if (preuser) {
      res.status(404).json("this city is already present");
    } else {
      const adduser = new cities({
        city,
      });
      // const token=await adduser.authUser();
      await adduser.save();
      res.status(201).json(adduser);
      console.log(adduser);
    }
  } catch (error) {
    res.status(404).json(error);
  }
});

router.get("/getcity", requireSignin, async (req, res) => {
  try {
    let data = await cities.find();
    res.status(201).json(data);
    console.log(data);
  } catch (error) {
    res.status(404).json(error);
  }
});

router.delete("/deletecity/:_id", requireSignin, async (req, res) => {
  try {
    let data = await cities.deleteOne(req.params);
    console.log(data);
    res.status(201).json(data);
  } catch (error) {
    res.status(404).json(error);
  }
});

module.exports = router;
