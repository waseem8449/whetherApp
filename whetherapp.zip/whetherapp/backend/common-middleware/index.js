const jwt = require("jsonwebtoken");

exports.requireSignin = (req, res, next) => {
  const token = req.headers.authorization;
  if (!token) {
    res.status(404).json({ message: "token is not there" });
  }
  const user = jwt.verify(token, "waseem");
  console.log("data------------", user);
  req.user = user;

  next();
};
