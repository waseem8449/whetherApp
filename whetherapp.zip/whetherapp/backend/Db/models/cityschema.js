const mongoose = require("mongoose");
const cityschema = new mongoose.Schema({
  city: {
    type: String,
    required: true,
  },
});

module.exports = mongoose.model("city", cityschema);
