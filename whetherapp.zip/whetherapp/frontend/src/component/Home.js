import React, { useEffect, useState } from "react";
import { useHistory } from "react-router-dom";
import { Button } from "reactstrap";

const Home = () => {
  const [cities, setcities] = useState();
  const [showCities, setshowCities] = useState();
  const [userdata, setUserdata] = useState([]);
  const [showModal, setshowModal] = useState(false);
  const history = useHistory();
  const token = localStorage.getItem("token");

  const routeChange = () => {
    let path = `/addCity`;
    history.push(path);
  };
  const getdata = async (e) => {
    // e.preventDefault();
    const res = await fetch("/getCity", {
      method: "GET",
      headers: {
        "content-Type": "application/json",
        authorization: token ? `${token}` : "",
      },
    });
    const data = await res.json();
    console.log(data);
    if (res.status === 404 || !data) {
      alert("error");
      console.log("error");
    } else {
      setUserdata(data);
      console.log("get data ");
    }
  };
  const deleteuser = async (id) => {
    const res2 = await fetch(`/deletecity/${id}`, {
      method: "DELETE",
      headers: {
        "Content-Type": "application/json",
        authorization: token ? `${token}` : "",
      },
    });
    const deletedata = await res2.json();
    console.log(deletedata);
    if (res2.status === 422 || !deletedata) {
      alert("error");
      console.log("error");
    } else {
      alert("user deleted ");
      getdata();
      console.log("user deleted ");
    }
  };

  const showData = async (element) => {
    console.log("cities", element);
    const url = `https://api.openweathermap.org/data/2.5/weather?q=${element}&appid=9ed7d2ee0fb3904841886da69c4743e5`;
    const res = await fetch(url);
    const data = await res.json();
    console.log(data);
    if (res.status === 404 || !data) {
      alert("data not found");
      console.log("error");
    } else {
      setcities(data);
      console.log("get data ");
    }
  };
  function getTime() {
    // let week = new Array(7);
    let week = ["Sun", "Monday ", "Tuesday ", "Wed", "Thurs", "Fri ", "Sat"];
    let month = [
      "jan",
      "feb",
      "mar",
      "april",
      "may",
      "jun",
      "july",
      "aug",
      "sep",
      "oct",
      "nov",
      "dec",
    ];
    let currentTime = new Date();
    let day = currentTime.getDay();
    let hours = currentTime.getHours();
    let mins = currentTime.getMinutes();
    let date = currentTime.getDate();
    let mon = currentTime.getMonth();
    // let year = currentTime.getFullYear();
    // let time = currentTime.getTime();
    let per = "AM";
    if (hours > 11) {
      per = "PM";
    }
    if (hours > 12) {
      hours = hours - 12;
    }
    if (mins < 10) {
      mins = "0" + mins;
    }
    return `${hours}:${mins}${per} |  ${date} ${week[day]}/${month[mon]} `;
  }
  useEffect(() => {
    getdata();
  }, []);
  return (
    <>
      {showModal && (
        <div className="  d-flex justify-content-center align-items-center  mt-5 w-60 h-72  ">
          <div
            className="border border-white shadow-lg "
            style={{
              backgroundImage: `url("pexel.webp")`,
              zIndex: 1,
            }}
          >
            <button
              className="bg-transparent border-0 text-end"
              onClick={() => setshowModal(false)}
            >
              <span className="text-white h-10 w-10  fs-1">x</span>
            </button>
            <h1 className="text-white text-center">Temperature App</h1>
            <div className="d-flex-col align-items-center justify-content-between p-5 mx-5">
              <thead>
                <h3>
                  <td className="table-dark">
                    <tr scope="col">
                      city
                      <td scope="col">
                        <span className="mx-5 text-white ">
                          {" "}
                          {cities?.name}{" "}
                        </span>
                      </td>
                    </tr>
                    <tr scope="col">
                      Temp
                      <td scope="col">
                        <span className="mx-5 text-white ">
                          {Math.floor(cities?.main?.temp - 273.15)}° C
                        </span>
                      </td>
                    </tr>
                    <tr scope="col">
                      min temp
                      <td scope="col">
                        <span className=" mx-5 text-white ">
                          {Math.floor(cities?.main?.temp_min - 273.15)}° C
                        </span>
                      </td>
                    </tr>
                    <tr scope="col">
                      max Temp
                      <td scope="col">
                        <span className=" mx-5 text-white ">
                          {Math.floor(cities?.main?.temp_max - 273.15)}° C
                        </span>
                      </td>
                    </tr>
                    <tr scope="col">
                      Time
                      <td scope="col">
                        <span className=" mx-5 text-white ">{getTime()}</span>
                      </td>
                    </tr>
                  </td>
                </h3>
              </thead>
              {/* <div>
                <i className="fa-solid fa-sun fs-1 mb-5" />
              </div> */}

              <div></div>
            </div>
          </div>
        </div>
      )}
      <div className="mt-5" style={{ zIndex: 999 }}>
        <div className="container">
          <div className="add_btn mt-2 mb-2">
            <Button onClick={routeChange}>Add city</Button>
          </div>
          <table className="table">
            <thead>
              <tr className="table-dark">
                <th scope="col">id</th>
                <th scope="col">city</th>
                <th scope="col">action</th>
                <th scope="col">delete</th>
              </tr>
            </thead>
            <tbody>
              {userdata.map((element, id) => {
                return (
                  <>
                    <tr>
                      <th key={id * 2} scope="row">
                        {id + 1}
                      </th>
                      <td>{element.city}</td>

                      <td className="d-flex justify-content-between">
                        <button
                          className="btn btn-primary"
                          onClick={() => {
                            setshowModal(true);
                            showData(element.city);
                          }}
                        >
                          show
                        </button>
                      </td>
                      <td>
                        <button
                          className="btn btn-danger"
                          onClick={() => deleteuser(element._id)}
                        >
                          delete
                        </button>
                      </td>
                    </tr>
                  </>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
};
export default Home;
